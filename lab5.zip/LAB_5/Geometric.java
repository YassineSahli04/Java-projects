public class Geometric extends AbstractSeries {

    public static final double r=0.5;
    private int q=1;
    public double next()
    {
        double resultat =  (Math.pow(r,q)-1) / (r-1) ;
        q++ ;
        return resultat;
    }
}
