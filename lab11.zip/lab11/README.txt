Student name: Yassine Sahli
Student number: 300383586
Course code: ITI 1521
Lab section: B00

Cette archive contient les 4 fichiers du laboratoire 11.

Spécifiquement, ce fichier (README.txt), ainsi que
Iterator.java, BitList.java, Iterative.java.
