Nom d'etudiant(e): Yassine Sahli
Numero d'etudiant: 300383586
Code de cours: ITI1521
Section de lab: B02

Cette archive contient les 3 fichiers du laboratoire 10.

Spécifiquement, ce fichier (README.txt), ainsi que
OrderedStructure.java, OrderedList.java.