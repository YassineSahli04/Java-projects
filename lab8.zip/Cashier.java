public class Cashier {
    private Queue queue;
    private Customer currentCustomer;
    private int customersServed;
    private int totalCustomerWaitTime;
    private int totalltemsServed;

    public Cashier() {
        queue = new ArrayQueue<>();

        currentCustomer=null;
        customersServed = 0;
       totalCustomerWaitTime = 0;
       totalltemsServed = 0;

    }

    public void addCustomer(Customer c) {

        queue.enqueue(c);
    }

    public int getQueueSize() {
        return queue.size();
    }

    public void serveCustomers(int currentTime) {
        if (currentCustomer == null) {


            if (!queue.isEmpty()) {

                currentCustomer = (Customer) queue.dequeue();
                totalCustomerWaitTime =
                        totalCustomerWaitTime + currentTime - currentCustomer.getArrivalTime();
                //si le customer a 0 items
                //customersServed++;
                if (currentCustomer.getNumberOfItems() != 0) {
                    currentCustomer.serve();
                } else {
                    customersServed++;
                    totalltemsServed = totalltemsServed + currentCustomer.getNumberOfServedItems();
                    currentCustomer = null;
                }
            }


        }

        if (currentCustomer != null) {
            if (currentCustomer.getNumberOfItems() != 0) {
                currentCustomer.serve();
            } else {
                customersServed++;
                totalltemsServed = totalltemsServed + currentCustomer.getNumberOfServedItems();
                currentCustomer = null;
            }
        }
    }


        public int getTotalCustomerWaitTime () {
            return totalCustomerWaitTime;
        }

        public int getTotalItemsServed () {
            if (this.currentCustomer != null)
                return totalltemsServed + this.currentCustomer.getNumberOfServedItems();
            else
                return totalltemsServed;
        }

        public int getTotalCustomersServed () {
            return customersServed;
        }

        public String toString () {
            return "The total number of customers served is " + getTotalCustomersServed() + '\n' + "The average number of items per customer was" +
                    getTotalCustomerWaitTime() / getTotalCustomersServed() + '\n' + "The average waiting time (in seconds) was" + getTotalItemsServed() / getTotalCustomersServed();


        }
    }

