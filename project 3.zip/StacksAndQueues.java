import java.util.EmptyStackException;

public class StacksAndQueues{
    
  //TODO: Ajouter vos 6 methodes ici
  

    public static void main (String[] args){
        Queue<String> q1;
        q1 = new LinkedQueue<String>();
        q1.enqueue ("a");
        q1.enqueue ("b");
        q1.enqueue ("c");
        q1.enqueue ("d");
        System.out.println("reverse Queue");
        System.out.println(q1);
        StacksAndQueues.reverseQueue(q1);
        System.out.println(q1);
        System.out.println();

        Stack<String> s1;
        s1 = new LinkedStack<String>();
        s1.push ("a");
        s1.push ("b");
        s1.push ("c");
        s1.push ("d");
        System.out.println("reverse Stack");
        System.out.println(s1);
        StacksAndQueues.reverseStack(s1);
        System.out.println(s1);
        System.out.println();

        Queue<String> q2;
        q2 = new LinkedQueue<String>();
        q2.enqueue ("a");
        q2.enqueue ("b");
        q2.enqueue ("c");
        q2.enqueue ("a");
        q2.enqueue ("b");
        q2.enqueue ("c");
        q2.enqueue ("a");
        q2.enqueue ("b");
        q2.enqueue ("c");
        System.out.println("remove All a for Queue");
        System.out.println(q2);
        StacksAndQueues.removeAll(q2, "a");
        System.out.println(q2);
        System.out.println();

        Stack<String> s2;
        s2 = new LinkedStack<String>();
        s2.push ("a");
        s2.push ("b");
        s2.push ("c");
        s2.push ("a");
        s2.push ("b");
        s2.push ("c");
        s2.push ("a");
        s2.push ("b");
        s2.push ("c");
        System.out.println("remove All a for Stack");
        System.out.println(s2);
        StacksAndQueues.removeAll(s2, "a");
        System.out.println(s2);
        System.out.println();

        Queue<String> q3;
        q3 = new LinkedQueue<String>();
        q3.enqueue ("a");
        q3.enqueue ("b");
        q3.enqueue ("c");
        q3.enqueue ("a");
        q3.enqueue ("b");
        q3.enqueue ("c");
        q3.enqueue ("a");
        q3.enqueue ("b");
        q3.enqueue ("c");
        System.out.println("remove First a for Queue - Scenario 1");
        System.out.println(q3);
        StacksAndQueues.removeFirst(q3, "a");
        System.out.println(q3);
        System.out.println();

        //removeFirst queue 2e exemple
        Queue<String> q4;
        q4 = new LinkedQueue<String>();
        q4.enqueue ("a");
        q4.enqueue ("b");
        q4.enqueue ("c");
        q4.enqueue ("a");
        q4.enqueue ("b");
        q4.enqueue ("c");
        q4.enqueue ("a");
        q4.enqueue ("b");
        q4.enqueue ("c");
        System.out.println("remove First b for Queue - Scenario 2");
        System.out.println(q4);
        StacksAndQueues.removeFirst(q4, "b");
        System.out.println(q4);
        System.out.println();

        Stack<String> s3;
        s3 = new LinkedStack<String>();
        s3.push ("a");
        s3.push ("b");
        s3.push ("c");
        s3.push ("a");
        s3.push ("b");
        s3.push ("c");
        s3.push ("a");
        s3.push ("b");
        s3.push ("c");
        System.out.println("remove First c for Stack - Scenario 1");
        System.out.println(s3);
        StacksAndQueues.removeFirst(s3, "c");
        System.out.println(s3);
        System.out.println();

        //removeFirst stack 2e exemple
        Stack<String> s4;
        s4 = new LinkedStack<String>();
        s4.push ("a");
        s4.push ("b");
        s4.push ("c");
        s4.push ("a");
        s4.push ("b");
        s4.push ("c");
        s4.push ("a");
        s4.push ("b");
        s4.push ("c");
        System.out.println("remove First b for Stack - Scenario 2");
        System.out.println(s4);
        StacksAndQueues.removeFirst(s4, "b");
        System.out.println(s4);
        System.out.println();
    }
    public static void reverseQueue(Queue<String> queue) {
        if (queue == null) {
            throw new IllegalArgumentException();
        } else {
            LinkedStack<String> tmp = new LinkedStack<String>();
            while (!queue.isEmpty()) {
                tmp.push(queue.dequeue());

            }
            while (!tmp.isEmpty()) {
                String saved = tmp.pop();
                queue.enqueue(saved);
            }
        }
    }

    public static void reverseStack(Stack<String> stack) {
        if (stack == null) {
            throw new IllegalArgumentException();
        }
        else {
            Stack<String> firstTmp = new LinkedStack<String>();
            Stack<String> secondTmp = new LinkedStack<String>();
            while (!stack.isEmpty()) {
                String saved = stack.pop();
                firstTmp.push(saved);
            }
            while (!firstTmp.isEmpty()) {
                String saved = firstTmp.pop();
                secondTmp.push(saved);
            }
            while (!secondTmp.isEmpty()) {
                String saved = secondTmp.pop();
                stack.push(saved);
            }
        }
    }

    public static void removeAll(Queue<String> queue, String toRemove){
        if (queue == null){
            throw new IllegalArgumentException();
        }
        else if(queue.isEmpty()) {
            throw new EmptyQueueException();
        }
        else {
            Queue<String> tmp = new LinkedQueue<String>();
            int count = 0;
            while (!queue.isEmpty()) {
                tmp.enqueue(queue.dequeue());
                count++;
            }
            for (int i = 0; i < count; i++) {
                String saved = tmp.dequeue();
                if (!saved.equals(toRemove)) {
                    tmp.enqueue(saved);
                }
            }
            while (!tmp.isEmpty()) {
                queue.enqueue(tmp.dequeue());
            }
        }
    }
    public static void removeAll(Stack<String> stack, String toRemove){
        if (stack == null){
            throw new IllegalArgumentException();
        }
        else if(stack.isEmpty()) {
            throw new EmptyStackException();
        }
        else {
            Stack<String> tmp = new LinkedStack<String>();
            while (!stack.isEmpty()) {
                String saved = stack.pop();
                if (!saved.equals(toRemove)) {
                    tmp.push(saved);
                }
            }
            while (!tmp.isEmpty()) {
                String saved = tmp.pop();
                stack.push(saved);
            }
        }
    }
    public static void removeFirst(Queue<String> queue, String toRemove){
        if (queue == null){
            throw new IllegalArgumentException();
        }
        else if(queue.isEmpty()) {
            throw new EmptyQueueException();
        }
        else {
            Queue<String> tmp = new LinkedQueue<String>();
            int count = 0;
            while (!queue.isEmpty()) {
                tmp.enqueue(queue.dequeue());
                count++;
            }
            boolean found = false;
            for (int i = 0; i < count; i++) {
                String saved = tmp.dequeue();
                if (!saved.equals(toRemove)) {
                    tmp.enqueue(saved);

                }
                else if(found){
                    tmp.enqueue(saved);
                }
                else{
                    found = true;
                }
            }
            while (!tmp.isEmpty()) {
                queue.enqueue(tmp.dequeue());
            }
        }
    }

    public static void removeFirst(Stack<String> stack, String toRemove){
        if (stack == null){
            throw new IllegalArgumentException();
        }
        else if(stack.isEmpty()) {
            throw new EmptyStackException();
        }
        else {
            Stack<String> tmp = new LinkedStack<String>();
            boolean found = false;
            while (!stack.isEmpty()) {
                String saved = stack.pop();
                if (!saved.equals(toRemove)) {
                    tmp.push(saved);

                }
                else if(found){
                    tmp.push(saved);
                }
                else{
                    found = true;
                }
            }
            while (!tmp.isEmpty()) {
                String saved = tmp.pop();
                stack.push(saved);
            }
        }
    }
}