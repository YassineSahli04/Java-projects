public class NotEnoughMoneyException extends IllegalStateException{
    private double number;
    private double balance;
    public NotEnoughMoneyException(String s,double number,double balance){
        super(s);
        this.number=number;
        this.balance=balance;
    }
    public double getBalance(){
        return balance;

    }
    public double getAmount(){return number;}
    public double getMissingAmount(){return number-balance;}
}
