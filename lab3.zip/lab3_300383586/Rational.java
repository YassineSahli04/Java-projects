public class Rational {

    private int numerator;
    private int denominator;

    // constructors

    public Rational(int numerator) {
        // Your code here
	     this.numerator = numerator;
         denominator = 1;
    }

    public Rational(int numerator, int denominator) {
	     // Your code here
        this.numerator = numerator;
        this.denominator = denominator;
        reduce();
    }

    // getters

    public int getNumerator() {
	     return numerator;
    }

    public int getDenominator() {
	     return denominator;
    }

    // instance methods

    public Rational plus(Rational other) {
	     // Your code here
        if (this.denominator == other.denominator) {
            int sumNumerator = this.numerator + other.numerator;
            int sumDenominator = this.denominator ;
            Rational sum = new Rational(sumNumerator, sumDenominator);
            return sum;
        }
        else{
            int sumNumerator = this.numerator * other.getDenominator() + this.denominator * other.getNumerator();
            int sumDenominator = this.denominator * other.getDenominator();
            Rational sum = new Rational(sumNumerator, sumDenominator);

            return sum;
        }

    }

    public static Rational plus(Rational a, Rational b) {
        Rational sum = a.plus(b);
        return sum;
    }

    // Transforms this number into its reduced form

    private void reduce() {
      // Your code here
        int simplification = gcd(numerator,denominator);
        numerator =numerator/simplification;
        denominator = denominator / simplification;

    }

    // Euclid's algorithm for calculating the greatest common divisor
    private int gcd(int a, int b) {
      // Note that the loop below, as-is, will time out on negative inputs.
      // The gcd should always be a positive number.
      // Add code here to pre-process the inputs so this doesn't happen.
        if (a < 0){a =-a;}
        if (b < 0){b =-b;}
    	while (a != b)
    	    if (a > b)
    		     a = a - b;
    	    else
    		     b = b - a;
    	return a;
    }

    public int compareTo(Rational other) {
      // Your code here
        float resultThis = ((float)this.numerator / (float)this.denominator);
        float resultOther = ((float)other.numerator / (float)other.denominator);
        if (resultThis<resultOther){
            return -1;
        }
        else if (resultThis>resultOther){
            return 1;
        }
        else{
            return 0;
        }
    }

    public boolean equals(Rational other) {
        double resultThis = (this.numerator/this.denominator);
        double resultOther = (other.numerator/ other.denominator);
        if (resultThis == resultOther){
          return true;
        }
        else{
          return false;
        }
    }

    public String toString() {
    	String result = "";
    	if (denominator == 1) {
    	    // Your code here
            result += String.valueOf(numerator);

    	} else {
    	    // Your code here
            result += String.valueOf(numerator) + "/" + String.valueOf(denominator);

        }
    	return result;
    }

}
