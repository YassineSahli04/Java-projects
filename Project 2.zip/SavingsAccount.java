/**
 * classe  SavingsAccount
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/08/2024
 */
public class SavingsAccount extends BankAccount {//TODO veuillez completer la declaration {
    private String accountId;
    private Double interestRate; 

    public SavingsAccount(char[] bankInstitution, String transit, Person owner, String shortAccountNumber, Double interestRate) {
        //
        //TODO: Veuillez ajouter votre code ici 
        //
        super(owner);
        this.accountId = transit ;
        for (int i = 0; i < bankInstitution.length; i++){
            this.accountId += bankInstitution[i] ;
        }
        this.accountId += shortAccountNumber;
        int checkDigit = (Utils.generateRandomEvenNumber() + 1)%10;
        accountId += String.valueOf(checkDigit);
        this.interestRate = interestRate;
    }

    public SavingsAccount(char[] bankInstitution, String transit, Person owner, Double interestRate) {
        this(bankInstitution, transit, owner, String.valueOf(Bank.getNextAccountNumber()), interestRate);
        int checkDigit = (Utils.generateRandomEvenNumber() + 1)%10;
        accountId += String.valueOf(checkDigit);
    }

    public void setInterestRate (Double interestRate) {
        this.interestRate = interestRate;
    }

    //
    //TODO: Veuillez completer les codes des methodes qui manquent 
    //
    public String getId() {return accountId;}


    public String getMetadata() {
        String accountType = "saving";
        String rateString = String.valueOf(interestRate);
        return "[" + accountType + ", rate=" + rateString + "]" ;
    }
}