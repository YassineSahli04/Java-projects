Nom d'etudiants: Yassine Sahli / Yasser EL Mouatadir
Numero d'etudiant: 300383586 / 300383470
Code de cours: ITI1121

Cette archive contient les 9 fichiers du Devoir 1, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Person.java, UnitTestPerson.java, Utils.java, TestUtils.java, JUnit-4.13.jar, Hamcrest-core-1.3.jar, TestDevoir1.java, StudentInfo.java.
