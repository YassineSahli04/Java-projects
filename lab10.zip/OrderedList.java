import java.util.NoSuchElementException;

public class OrderedList implements OrderedStructure {

    // Implementation of the doubly linked nodes (nested-class)

    private static class Node {

        private Comparable value;
        private Node previous;
        private Node next;

        private Node(Comparable value, Node previous, Node next) {
            this.value = value;
            this.previous = previous;
            this.next = next;
        }
    }

    // Instance variables

    private Node head;

    // Representation of the empty list.

    public OrderedList() {
        // Your code here.
        head = new Node(null,head,head);

    }

    // Calculates the size of the list

    public int size() {
        // Remove line below and add your implementation.
        int i = 0;
        Node x;
        x = head.next;
        if (x == null) {
            return i;
        }
        while (x != head) {
            x = x.next;
            i++;

        }
        return i;
    }


    public Object get(int pos) {
        // Remove line below and add your implementation.
        if (pos>size() || pos<0){
            throw new IndexOutOfBoundsException();
        }
        Node x;
        x = head.next;

        for ( int i=0; i<pos; i++ ) {
            x = x.next;
        }

        return x.value;
    }
    public boolean add( Comparable o ) {
        // Remove line below and add your implementation.
        boolean resultat = false;
        if(o == null){
            throw new NullPointerException();
        }

        Node  x ;
        x = head;
        if(x.next == null){
           Node newNode = new Node (o, head,head);
           x.next = newNode;
           x.previous = newNode;
           return true;
        }

        x = x.next;
        while (x != head) {
            int compare = x.value.compareTo(o);
            if (compare == 0) {
                return false;
            }
            else if (compare < 0) {
                x = x.next;
            }
            else {
                Node newnode = new Node(o, x.previous, x);
                x.previous.next = newnode;
                x.previous = newnode;
                x = x.next;
                resultat = true;
                return resultat;
            }
        }
        x = x.previous;
        Node newnode=new Node(o,x,x.next);
        x.next.previous=newnode;
        x.next=newnode;

        resultat=true;
        return resultat;

    }



    //Removes one item from the position pos.

    public void remove( int pos ) {
        // Remove line below and add your implementation.
        if ( pos > size() || pos < 0){
            throw new IndexOutOfBoundsException();
        }
        Node x;
        x = head.next;
        for (int i=0; i<(pos); i++) {
            x = x.next;
        }
        x.previous.next= x.next;
        x.next.previous = x.previous;
    }

    // Knowing that both lists store their elements in increasing
    // order, both lists can be traversed simultaneously.

    public void merge( OrderedList other ) {


        int count=0;
        while(count!=other.size()){
            this.add((Comparable)other.get(count++));
        }
    }



}
