import java.lang.Math;
public abstract class AbstractSeries implements Series {

    public double[] take(int k) {

        // implement the method
        double[] tableau = new double[k];
        for (int i = 0; i < k; i++) {
            tableau[i] = next();
        }
        return tableau;
    }

}