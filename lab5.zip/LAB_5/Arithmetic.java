public class Arithmetic extends AbstractSeries{

    private int r=1;
    public double next()
    {
        double result = r*(r+1)/2.0;
        r++;
        return result;
    }
}
