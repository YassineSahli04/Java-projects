
Nom de l'étudiante : Yassine Sahli
Numéro d'étudiant: 300383586
Code du cours: ITI 1521

Cette archive contient les 8 fichiers du laboratoire 5.

Spécifiquement, ce fichier (README.txt), ainsi que
AbstractSeries.java, Arithmetic.java, Book.java, BookComparator.java, Geometric.java,
Library.java, Series.java.