public class LinkedList<E> implements List<E> {

    private static class Node<T> {
      private T value;
      private Node<T> prev;
      private Node<T> next;
      private Node(T value, Node<T> prev, Node<T> next) {
        this.value = value;
        this.prev = prev;
        this.next = next;
      }
    }
    
    private Node<E> head;
    private int size;
    
    public LinkedList() {
        head = new Node<E>(null, null, null);
        head.prev = head;
        head.next = head;
        size = 0;
    }

    public int size() {
      return size;
    }
 
    public E get(int pos) {
 
      if (pos < 0 || pos >= size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> p;
      p = head.next;
      
      while (pos > 0) {
        p = p.next;
        pos--;
      }

      return p.value;
    }

    public void add(E element, int pos) {

      if (element == null) {
        throw new NullPointerException();
      }
      
      if (pos < 0 || pos > size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> before, after;
      before = head;
      
      while (pos > 0) {
        before = before.next;
        pos--;
      }

      after = before.next;
      
      before.next = new Node<E>(element, before, after);
      after.prev = before.next;
      
      size++;
    }

    public void remove(int pos) {

      if (pos < 0 || pos >= size) {
        throw new IndexOutOfBoundsException(Integer.toString(pos));
      }
      
      Node<E> before, after;
      before = head;
      
      while (pos > 0) {
        before = before.next;
        pos--;
      }
      
      after = before.next.next;
      
      before.next = after;
      after.prev = before;
      
      size--;
    }


    public void merge (LinkedList<E> other) {
        //TODO: Ajouter votre code ici.
        //vous n avez pas le droit d appeler les methodes d instances de cette classe
        Node<E> p = other.head;
        Node<E> newNode;
        Node<E> afterOtherList;
        Node<E> beforeThisList;
        while (p.next != p){
            //saves the element
            newNode = p.next;

            //Ther other list
            afterOtherList = p.next.next;
            p.next = p.next.next;
            afterOtherList.prev =other.head;

            // The actual list
            beforeThisList = this.head.prev;
            this.head.prev = newNode;
            beforeThisList.next = newNode;
            newNode.next = this.head;
            newNode.prev = beforeThisList;
        }

        

    }

    //TODO: Ajouter votre code ici pour l iterateur

    private class LinkedListIterator implements Iterator<E> {
        private Node<E> current;
        private LinkedList<E> myList;

        private LinkedListIterator(LinkedList<E> myList) {
            this.myList = myList;
            current = null;
        }

        public E next() {
            if(hasNext()){
                if (current == null || current == myList.head.prev){
                    current = myList.head.next;
                }
                else{
                    current = current.next;
                }
                return current.value;
            }
            return null;
        }

        public E prev(){
            if(hasPrev()){
                if (current == null || current == myList.head.next){
                    current = myList.head.prev;
                }
                else{
                    current = current.prev;

                }
                return current.value;
            }
            return null;
        }

        public boolean hasNext() {
            if (current == null && myList.head == myList.head.next) {
                return false;
            }
            if (current != null && current.next.next == current){
                return false;
            }
            return true;
        }

        public boolean hasPrev(){
            if (current == null && myList.head == myList.head.prev) {
                return false;
            }
            else if (current != null && current.prev.prev == current) {
                return false;
            }
            return true;
        }
    }

    public Iterator<E> iterator() {
        return new  LinkedListIterator(this);
    }
    
    
    public String toString() {

      StringBuffer b;
      b = new StringBuffer("LinkedList [");
      
      Node<E> p;
      p = head.next;
      
      while (p != head) {
        b.append(p.value);
        if (p.next != head) {
          b.append(",");
        }
        p = p.next;
      }
      
      b.append("]");
      
      return b.toString();
    }


}
