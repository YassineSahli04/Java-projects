public class Q3_ArrayInsertionDemo{

    public static int[] insertIntoArray(int[] beforeArray, int indexToInsert, int valueToInsert) {
        // votre code ici
        if (indexToInsert < 0 || indexToInsert > beforeArray.length) {
            System.out.println("Index invalide ") ;
            return beforeArray;
        }

        int[] afterArray = new int[beforeArray.length  +  1] ;
        for (int i = 0 ; i < indexToInsert; i++ ) {
            afterArray[i]  = beforeArray[i];
        }

        afterArray[indexToInsert] =  valueToInsert;
        for (int i = indexToInsert + 1; i < afterArray.length; i++) {
            afterArray[i] = beforeArray[i - 1] ;
        }

        return afterArray ;
    }

    public static void main(String[] args){
        // votre code ici
        int[] arrayBeforeInsertion = {1,5,4,7,9,6} ;

        System.out.println("Tableau avant l'insertion: ");
        for (int valeur : arrayBeforeInsertion) {
            System.out.println(valeur) ;
        }
        int indexToInsert = 3 ;
        int valueToInsert = 15 ;

        int[] arrayAfterInsertion = insertIntoArray(arrayBeforeInsertion, indexToInsert, valueToInsert) ;

        System.out.println("Tableau après insertion de " + valueToInsert + " à la position " + indexToInsert + ":") ;
        for (int valeur : arrayAfterInsertion) {
            System.out.println(valeur) ;
        }
    }
}
