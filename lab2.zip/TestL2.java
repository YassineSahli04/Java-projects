public class TestL2 {

   public static void main(String[] args) {
    TestUtils.runClass(TestL2Combination.class);
    TestUtils.runClass(TestL2DoorLock.class);
  }

}
