/**
 * classe abstraite BankAccount
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/08/2024
 */
abstract class BankAccount extends Account implements ITextMetadata {//TODO veuillez completer la declaration {
    protected double balance;

    public BankAccount(Person accountHolder) {
        this(accountHolder, 0.0);
    }

    public BankAccount(Person accountHolder, double balance) {
        super.accountHolder = accountHolder;
        this.balance = balance;
    }

    public double getBalance() {
        return balance;
    }
    
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("Détenteur/" + this.getAccountHolder() + "/AccountNumber:" + this.getId() + this.getMetadata() +  "/Balance: " + this.getBalance() + "\n");
        return sb.toString();
    }

    public boolean equals(BankAccount account) {
        //
        //TODO: Veuillez ajouter votre code ici 
        //
        boolean isEqual = false;
        if (account != null) {
            String thisAccountIdWithoutLastCheckDigit = this.getId().substring(0, this.getId().length() - 1);
            String accountIdWithoutLastCheckDigit = account.getId().substring(0, account.getId().length() - 1);
            if (thisAccountIdWithoutLastCheckDigit.equals(accountIdWithoutLastCheckDigit)) {
                isEqual = true;
            }
        }
        return isEqual;

    }
}