/**
 * classe  ChequingAccount
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/08/2024
 */
public class ChequingAccount extends BankAccount { //TODO veuillez completer la declaration {
    private String accountId;

    public ChequingAccount(char[] bankInstitution, String transit, Person owner, String shortAccountNumber) {
        //
        //TODO: Veuillez ajouter votre code ici 
        //
        super(owner);
        this.accountId = transit ;
        for (int i = 0; i < bankInstitution.length; i++){
            this.accountId += bankInstitution[i] ;
        }
        this.accountId += shortAccountNumber;
        int checkDigit = Utils.generateRandomEvenNumber();
        accountId += String.valueOf(checkDigit);
    }

    public ChequingAccount(char[] bankInstitution, String transit, Person owner) {
        this(bankInstitution, transit, owner, String.valueOf(Bank.getNextAccountNumber()));
        int checkDigit = Utils.generateRandomEvenNumber();
        accountId += String.valueOf(checkDigit);
    }

    //
    //TODO: Veuillez completer les codes des methodes qui manquent 
    //

    public String getId() {return accountId;}


    public String getMetadata() {
        String accountType = "chequing";
        return "[" + accountType + "]";
    }

}