public class Combination {
    // Instance variables.
    int first; int second; int third;
    // Constructor
    public Combination( int first, int second, int third ) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    public boolean equals( Combination other ) {
        if (other == null){
            return false;
        }
        else if ((this.first == other.first) && (this.second == other.second) && (this.third == other.third) ){
            return true;
        }
        return false;
    }

    // Returns a String representation of this Combination.

    public String toString() {
        // Put your code here and remove the line below
        return first + ":" + second + ":" + third;
    }

}
