import java.util.*;

class Q6 {
	public static void main(String[] args) {

  	    // votre code ici

        Scanner scan = new Scanner(System.in) ;
        double[] note = new double[10];

        System.out.println("Entrez vos dix notes: ") ;
        for (int i = 0 ; i <= 9 ; i++) {
            System.out.print("Note " + (i+1) + ": ") ;
            note[i] = scan.nextDouble() ;
        }

        System.out.println("La moyenne des notes est:" + calculateAverage(note)) ;
        System.out.println("La médiane des notes est:" + calculateMedian(note)) ;
        System.out.println("Le nombre d'échec est:" + calculateNumberFailed(note)) ;
        System.out.println("Le nombre de réussite est:" + calculateNumberPassed(note)) ;

	}

	public static double calculateAverage(double[] notes) {
	    // votre code ici

        double resultat;
        resultat = 0.0;
        for (double note : notes) {
            resultat += note;
        }
        return resultat / notes.length ;

	}

	public static double calculateMedian(double[] notes) {
	    // votre code ici
        Arrays.sort(notes);
        int x = notes.length / 2 ;
        if (notes.length % 2 ==  0) {
            return (notes[x - 1] + notes[x]) / 2 ;
        }
        else {
            return notes[x] ;
        }

	}

	public static int calculateNumberFailed(double[] notes) {
	    // votre code ici

        int pas = 0 ;
        for (double note : notes) {
            if (note < 50) {
                pas++;
            }
        }
        return pas;
	}

	public static int calculateNumberPassed(double[] notes) {
	    // votre code ici

        return notes.length - calculateNumberFailed(notes) ;

	}

}
