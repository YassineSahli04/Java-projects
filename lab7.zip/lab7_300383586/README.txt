Nom de l'étudiante ou de l'étudiant: Yassine Sahli
Numéro d'étudiant: 300383586
Code du cours: ITI1521Section de laboratoire: B02
Cette archive contient les 11 fichiers du laboratoire 7.

Spécifiquement, ce fichier (README.txt), ainsi que
Exercise1.java, Account.java, NotEnoughMoneyException.java, Stack.java, ArrayStack.java, DynamicArrayStack.java, FullStackException.java, Map.java, Dictionary.java, Pair.java.
