import java.time.LocalDate;
import java.time.Period;

/**
 * la classe Personne qui garde les informations d une personne
 *
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 01/24/2024
 */
public class Person {
    //le format du nas, ici en bloc de 3 chiffres e.g. 123 456 789.  Si NASGROUPFORMAT=2, alors on aurait 12 34 56 78 9
    public static int NASGROUPFORMAT = 3;

    //la longueur du nas, au canada le nas est compose de 9 chiffres
    public static final int NASLENGTH = 9;

    //variable d'instance
    private String name;
    private int[] dateOfBirth;
    //TODO: Veuillez ajouter votre code ici  pour déclarer votre variable d instance nas en tant que tableau d Integer
    private Integer[] nas;

    // Constructor
    /**
     *
     * <p>Construit un object Person </p>
     *
     * @param name le nom de la personne
     */
    public Person (String name) {
        this.name = name;
    }

     /**
     *
     * <p>Construit un object Person </p>
     *
     * @param name le nom de la personne
     * @param dateOfBirthString la date de naissance en format AAAA-MM-JJ
     */
     public Person (String name, String dateOfBirthString) {
        //TODO: Veuillez ajouter votre code ici
         this.name = name;
         setDateOfBirth(dateOfBirthString);
    }

    //getters method

    /**
     * retourne le nom
     *
     * @return le nom de la personne
     */
    public String getName() {
        return this.name;
    }

    /**
     * retourne la date de naissance
     *
     * @return la date de naissance en tableau de int
     */
    public int[] getDateOfBirth() {
        return this.dateOfBirth;
    }


    /**
     * retourne le numero d assurance en social en fomrat NASGROUPFORMAT e.g. "123 456 789"
     *
     * @return le nas
     */
    public String getNas() {
         //TODO: Veuillez ajouter votre code ici
        StringBuilder format_nas = new StringBuilder();
        if(nas != null){
            for (int i = 0; i<nas.length; i++) {
                format_nas.append(nas[i]);
                if (i<nas.length-1) {
                    format_nas.append(" ");
                }

            }
        }
        String nasString = format_nas.toString();
        return nasString;
    }

     // Setter methods

     /**
     *
     * <p>met en place le nom de la personne</p>
     * @param  name le nom
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * <p>met en place le date de naissance de la personne</p>
     * @param  dateOfBirthString en format AAAA-MM-JJ
     */
    public void setDateOfBirth(String dateOfBirthString) {
        this.dateOfBirth = parseDateOfBirth(dateOfBirthString);
    }

    /**
     *
     * <p>met en place le numero d assurance sociale de la personne s il est valide</p>
     * @param nas compose uniquement de 9 chiffres (123456789 ou 123 456 789 etc)
     */
    public void setNas(String nas) {
        //TODO: Veuillez ajouter votre code ici
        //Hint: verifier que le parametre nas est valide et utiliser la methode de classe parseNas
        boolean validNas = isNasValid(nas);
        if (validNas) {
            this.nas = parseNas(nas, NASGROUPFORMAT);;
        }
    }

    // Methodes d'instance

    /**
     * retourne l age actuel de la personne
     *
     * @return l age
     */
    public int getCurrentAge() {

        //TODO: Veuillez ajouter votre code ici
        //Hint: utiliser la methode de classe calculateAgeAtDate
        LocalDate todayDate = LocalDate.now();
        int currentAge = calculateAgeAtDate(this, todayDate);
        return currentAge;
    }

    /**
     * retourne la version String de la personne en format "Nom ... , Date de naissance: [...], Nas: ... (si le nas existe) "
     * e.g Nom: Michael Jordan, Date de naissance: [17 février 1963]
     * e.g Nom: Marie Tremblay, Date de naissance: [1 juillet 1980], Nas: (123 456 789)
     * @return la version string de l objet Person
     */
    public String toString() {
        //TODO: Veuillez ajouter votre code ici
        String personneString;
        int[] birthArray = this.dateOfBirth;
        int dayNumber = birthArray[2];
        int monthNumber = birthArray[1];
        int yearNumber = birthArray[0];
        String month = Utils.convertMonthToFrenchString(monthNumber);
        String nasString = getNas();

        if(this.nas == null) {
            personneString = "Nom: " + this.name + ", Date de naissance: [" + dayNumber + " " + month + " " + yearNumber + "]";
        }
        else{
            personneString = "Nom: " + this.name + ", Date de naissance: [" + dayNumber + " " + month + " " + yearNumber + "], Nas: (" + nasString + ")";
        }
        return personneString;
    }

    //Methodes de classe

    /**
     * Méthode Helper pour calculer l'âge  par rapport a la date envoye en parametre
     * @param person la personne dont l age est a calculer
     * @param date la date de reference (e.g. date d aujourhui ou une date quelconque)
     * @return l age
     */
    public static int calculateAgeAtDate(Person person, LocalDate date) {
        //TODO: Veuillez ajouter votre code ici
        //Hint: inspirez vous des methodes utilitaires de la classe java.Time.LocalDate et java.Time.Period
        int[] birthArray = person.dateOfBirth;
        LocalDate dateBirth = LocalDate.of(birthArray[0],birthArray[1],birthArray[2]);
        Period period = Period.between(dateBirth,date);
        int age = period.getYears();
        return age;

        //Méthode sans utilisation de period.between

        /*
        int age;
        if(birthArray[1] < date.getMonthValue()){
            age = date.getYear() - birthArray[0];
        }
        else if (birthArray[1] > date.getMonthValue()) {
            age = date.getYear() - birthArray[0] -1;
        }
        else{
            if (birthArray[2] <= date.getDayOfMonth()){
                age = date.getYear() - birthArray[0];
            }
            else {
                age = date.getYear() - birthArray[0] -1;
            }
        }
        return age;*/
    }

    /**
     * Méthode Helper pour verifier si un nas est valide
     * @param input le nas
     * @return vrai si le nas est valide
     */
    public static boolean isNasValid(String input) {
        //TODO: Veuillez ajouter votre code ici
        String inputWithoutSpaces = input.replaceAll("\\s", "");
        boolean validInput = false;
        int counter = 0;
        if (inputWithoutSpaces.length() == 9){
            for(int i = 0; i < inputWithoutSpaces.length(); i++){
                char elementInput = inputWithoutSpaces.charAt(i);
                int chiffreInput = elementInput - '0';
                if ((i == 0) && (chiffreInput  == 0 )){
                    break;
                }
                if ( chiffreInput < 10 ){
                    counter ++;
                }

            }
            if (counter == 9){
                validInput = true;
            }
        }
        return validInput;
    }

    /**
     * Méthode Helper pour mettre la chaîne de caractere  date de naissance dans un tableau d'entiers
     * @param dateOfBirthString le  date de naissance en format AAAA-MM-JJ 
     * @return un tableau de int
     */
    private static int[] parseDateOfBirth(String dateOfBirthString) {
        // En supposant que la chaîne de date de naissance soit au format « AAAA-MM-JJ »
        String[] parts = dateOfBirthString.split("-");

        int year = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int day = Integer.parseInt(parts[2]);

        // Créer un tableau pour représenter la date de naissance
        int[] dateOfBirthArray = {year, month, day};

        return dateOfBirthArray;
    }

    /**
     *  Méthode Helper pour mettre la chaîne de caractere nas dans un tableau d'entiers
     * @param nas le  numero d assurance social
     * @param format la longueur de chaque bloc
     * @return un tableau de Integer
     */
    private static Integer[] parseNas (String nas, int format) {
        //TODO: Veuillez ajouter votre code ici
        //Hint: la methode java.lang.Math.ceil et la methode d instance substring de String  pourraientt vous aider
        boolean validNas = isNasValid(nas);
        Integer[] nasArray = new Integer[NASLENGTH/NASGROUPFORMAT];
        if (validNas) {
            int indexNasArray = 0;
            String nasPartStr = "";
            for (int i = 0; i < NASLENGTH; i++) {
                char numNas = nas.charAt(i);
                nasPartStr += numNas;
                if (((i + 1) % NASGROUPFORMAT == 0)) {
                    int nasPartInt = Integer.parseInt(nasPartStr);
                    nasArray[indexNasArray] = nasPartInt ;
                    indexNasArray ++;
                    nasPartStr = "";
                }
            }
            return nasArray;
        }
        return nasArray;
    }

    /**
     * Méthode principale
     * @param args parametres de la ligne de commande
     */
    public static void main(String[] args) {
        // Creating a Person object
        Person am = new Person("Mozart", "1756-01-27");
        Person jd = new Person("Jeanne D'arc", "1412-01-06");
        Person jesus = new Person("Jesus Christ", "0-12-25");
        Person mj = new Person("Michael Jordan");
        mj.setDateOfBirth("1963-02-17");
        Person mt = new Person("Marie Tremblay", "1980-7-1");
        mt.setNas("123456789");

        StudentInfo.display();

        System.out.println(am.toString() + ", Age: " + am.getCurrentAge());
        LocalDate dateDecesJd = LocalDate.of(1431, 5,30);
        System.out.println(jd.toString() + ", Age au decès: " + Person.calculateAgeAtDate(jd, dateDecesJd));
        System.out.println(jesus.toString() + ", Age: " + jesus.getCurrentAge());
        System.out.println(mj.toString() + ", Age: " + Person.calculateAgeAtDate(mj, LocalDate.now())); // une autre alternative de chercher l age
        System.out.println(mt.toString());
        System.out.println();
    }
}
