public class Book {

    // Your variables declaration here
    private String author;
    private String title;
    private int year;

    public Book (String author, String title, int year) {
        // Your code here
        this.author=author;
        this.title=title;
        this.year=year;
    }

    public String getAuthor() {
        // Your code here
        return author;
    }

    public String getTitle() {
        // Your code here
        return title;
    }

    public int getYear() {
        // Your code here
        return year;
    }

    public boolean equals(Object other) {
        // Your code here
        if(this==other) {
            return true;
        }
        if ((other instanceof Book)==false) {
            return false;
        }

        Book Other = (Book) other;

        if(this.getAuthor()== null && Other.getAuthor()!=null || this.getAuthor()!=null && Other.getAuthor()==null){
            return false;
        }
        if(this.getTitle() == null && Other.getTitle()!=null || this.getTitle()!=null && Other.getTitle()==null){
            return false;
        }
        if ((this.getAuthor()==null && Other.getAuthor()!=null )){
            return this.getTitle().equals(Other.getTitle())&&this.getYear()==Other.getYear();
        }
        if ((this.getTitle()==null && Other.getTitle()!=null )){
            return this.getAuthor().equals(Other.getAuthor())&&this.getYear()==Other.getYear();
        }
        if(this.getAuthor()==null && Other.getAuthor()==null) {
            return this.getTitle().equals(Other.getTitle())&&this.getYear()==Other.getYear();
        }

        if ( this.getTitle()==null && Other.getTitle()==null ){
            return this.getAuthor().equals(Other.getAuthor())&&this.getYear()==Other.getYear();
        }

        int authorComparison = this.getAuthor().compareTo(Other.getAuthor());

        if (authorComparison == 0) {
            authorComparison = this.getTitle().compareTo(Other.getTitle());
            if (authorComparison == 0) {
                authorComparison = Integer.compare(this.getYear(), Other.getYear());
            }
        }
        return authorComparison==0;
    }


    public String toString() {
        // Your code here
        return author+":"+title+"("+year+")";
    }
}
