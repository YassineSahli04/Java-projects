import java.util.Arrays;

public class Q3_ReverseSortDemo {
    public static void main(String[] args) {
        char[] unorderedLetters;
        unorderedLetters = new char[]{'b', 'm', 'z', 'a', 'u'};
        reverseSort(unorderedLetters);
        for (int i = 0; i < unorderedLetters.length; i++)
            System.out.print(unorderedLetters[i]);
    }

    public static void reverseSort(char[] valeur) {
        for (int i = 0; i < valeur.length - 1; i++) {
            for (int j = 0; j < valeur.length - 1 - i; j++) {
                if (valeur[j + 1] > valeur[j]) {
                    char t = valeur[j];
                    valeur[j] = valeur[j + 1];
                    valeur[j + 1] = t;
                }
            }
        }
    }
}