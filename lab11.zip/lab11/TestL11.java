public class TestL11 {

    public static void main(String[] args) {
        TestUtils.runClass(TestL11BitList.class);
        TestUtils.runClass(TestL11Iterative.class);
    }

}
