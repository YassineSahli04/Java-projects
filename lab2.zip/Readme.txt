Nom d'etudiant: Sahli Yassine
Numero d'etudiant: 300383586
Code de cours: ITI1521
Section de lab: B00

Cette archive contient les 3 fichiers du laboratoire 2, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Combination.java et DoorLock.java avec les fichiers de test.
