import java.util.Comparator;
public class BookComparator implements Comparator<Book> {
    // Implement the comparator method for books.
    @Override
    public int compare(Book book1, Book book2) {
        int bookcomparison = book1.getAuthor().compareTo(book2.getAuthor());
        if (bookcomparison == 0) {
            bookcomparison = book1.getTitle().compareTo(book2.getTitle());
            if (bookcomparison == 0) {
                bookcomparison= Integer.compare(book1.getYear(), book2.getYear());
            }
        }
        return bookcomparison;
    }

}
