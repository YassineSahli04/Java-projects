Nom d’étudiant(e): Khalil YAHYAOUI / Yassine Sahli
Numero d’étudiant: 300390610 / 300383586
Code de cours: ITI1521
Section: B02

Cette archive contient les fichiers du devoir 2, c'est-à-dire, ce fichier (README.txt),
puis les fichiers Utils.java, Person.java, Stack.java, ArrayStack.java, StudentInfo.java,
Bank.java, Branch.java, Account.java, BankAccount.java, ChequingAccount.java, SavingsAccount.java,
ITextMetadata.java et JournalOperations.java.