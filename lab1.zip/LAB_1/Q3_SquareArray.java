public class Q3_SquareArray {
    public static int[] createArray(int size) {
		// votre code ici
        int[] Array = new int[size];
        for (int i = 0; i < size; i++) {
            Array[i] = i * i;
        }
        return Array;
	}

	public static void main(String[] args){
		// votre code ici
        int size = 13; // Vous pouvez ajuster la taille du tableau selon vos besoins
        int[] f_Array = createArray(size);

        // Affichage des valeurs du tableau
        System.out.println("Les carrés des indices de 0 à " + (size - 1) + " sont :");
        for (int i = 0; i < size; i++) {
            System.out.println("The square of " + i + " is : " + f_Array[i]);
        }
	}
}
    

