/**
 * classe Bank
 * @author Livaniaina Rakotomalala (lrakotom@uottawa.ca)
 * @version 02/10/2024
 */
public class Bank {
    private static long NEXT_ACCOUNT_NUMBER = 500001;
    private String name;
    private char[] institution;
    private Branch[] branches;
 
    public Bank (String name, char[] institution, Branch[] branches) {
        this.name = name;
        this.institution = institution;
        this.branches = branches;
    }

    public String getName() {
        return this.name;
    }

   
    public void configureBankAccount(BankAccount bankAccount, String transitNumber, boolean isNewAccount){
        //
        //TODO: Veuillez ajouter votre code ici 
        //

        for (int i = 0; i < branches.length; i++) {
            if (branches[i].getTransitNumber().equals(transitNumber)) {
                if (isNewAccount) {
                    branches[i].addBankAccount(bankAccount);
                } else {
                    branches[i].recordBankAccount(bankAccount);
                }
            }
        }

    }

    public Double getDefaultInterestRate (String transitNUmber) {
        for (Branch branch : branches) {
            if (branch.getTransitNumber().equals(transitNUmber)) {
                return branch.getInterestRate();
            }
        }
        return 0.0;
    }

    public static long getNextAccountNumber () {
        return NEXT_ACCOUNT_NUMBER++;
    }

    public String toString() {
        //
        //TODO: Veuillez ajouter votre code ici 
        //
        String bankDetails = "Bank: " + name + ", Institution #: ";
        for (char c : institution) {
            bankDetails += c;
        }
        bankDetails += "\n"+"*****************************"+"\n";
        for (Branch branch : branches) {
            bankDetails += branch.toString() + "\n";
        }
        return bankDetails;
    }
}