public interface ITextMetadata {
    String getMetadata();
}